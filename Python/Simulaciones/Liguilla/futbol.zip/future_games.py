jornada8 = [["Tiburones", "Cruz Azul"],
            ["Atlas", "Tigres"],
            ["Queretaro", "Monarcas"],
            ["America","Lobos"], 
            ["Monterrey", "Puebla"],
            ["Necaxa","Xolos"],
            ["Pachuca","Chivas"],
            ["Pumas","Leon"],
            ["Santos", "Toluca"]]


jornada9 = [["Monarcas","America"],
            ["Xolos", "Atlas"],
            ["Cruz Azul", "Necaxa"],
            ["Leon","Santos"],
            ["Tigres","Pachuca"],
            ["Chivas","Monterrey"],
            ["Toluca","Tiburones"],
            ["Lobos","Pumas"],
            ["Puebla","Queretaro"]]
        
jornada10 = [["Tiburones","Santos"],
            ["Atlas","Cruz Azul"],
            ["Pachuca","Xolos"],
            ["America","Puebla"],
            ["Monterrey","Tigres"],
            ["Necaxa","Toluca"],
            ["Queretaro","Chivas"],
            ["Pumas","Monarcas"],
            ["Lobos","Leon"]]
        
jornada11 = [["Monarcas","Lobos"],
            ["Puebla", "Pumas"],
            ["Cruz Azul","Pachuca"],
            ["Chivas","America"],
            ["Tigres","Queretaro"],
            ["Xolos","Monterrey"],
            ["Toluca","Atlas"],
            ["Santos", "Necaxa"],
            ["Leon", "Tiburones"]]

jornada12 = [["Monarcas","Leon"],
            ["Atlas", "Santos"],
            ["Queretaro","Xolos"],
            ["Pachuca","Toluca"],
            ["America","Tigres"],
            ["Monterrey", "Cruz Azul"],
            ["Necaxa","Tiburones"],
            ["Pumas","Chivas"],
            ["Lobos", "Puebla"]]

jornada13 = [["Tiburones","Atlas"],
            ["Puebla","Monarcas"],
            ["Cruz Azul","Queretaro"],
            ["Tigres","Pumas"],
            ["Leon","Necaxa"],
            ["Chivas","Lobos"],
            ["Xolos","America"],
            ["Toluca","Monterrey"],
            ["Santos","Pachuca"]]

jornada14 = [["Puebla","Leon"],
            ["Atlas", "Necaxa"],
            ["Queretaro","Toluca"],
            ["Pachuca","Tiburones"],
            ["Monterrey","Santos"],
            ["Monarcas", "Chivas"],
            ["Pumas","Xolos"],
            ["Lobos","Tigres"],
            ["America","Cruz Azul"]]

jornada15 = [["Tiburones","Monterrey"],
            ["Xolos","Lobos"],
            ["Necaxa","Pachuca"],
            ["Leon","Atlas"],
            ["Cruz Azul","Pumas"],
            ["Tigres","Monarcas"],
            ["Chivas","Puebla"],
            ["Toluca","America"],
            ["Santos","Queretaro"]]

jornada16 = [["Puebla","Tigres"],
            ["Monarcas","Xolos"],
            ["Pachuca","Atlas"],
            ["America","Santos"],
            ["Monterrey","Necaxa"],
            ["Chivas","Leon"],
            ["Pumas","Toluca"],
            ["Lobos","Cruz Azul"],
            ["Queretaro","Tiburones"]]

jornada17 = [["Atlas","Monterrey"],
            ["Cruz Azul","Monarcas"],
            ["Leon","Pachuca"],
            ["Tigres","Chivas"],
            ["Tiburones","America"],
            ["Necaxa","Queretaro"],
            ["Toluca","Lobos"],
            ["Xolos","Puebla"],
            ["Santos","Pumas"]]