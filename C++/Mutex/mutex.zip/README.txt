Daniel Charua A01017419       18/10/17
The program most be compile like this
g++ mutex.cpp md5.cpp -o main -pthread
Then you should run ./main
It will ask you for the hash, if the word is found it will print it,
otherwise it will print not found in consumer number #
