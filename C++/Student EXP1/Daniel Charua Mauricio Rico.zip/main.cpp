/*
Daniel Charua / A01370874
Mauricio Rico / A01370874
Final Exam
14/09/16
*/
#define SIZE 16
#include "student.h"

#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;
// Function definitions
void user_menu();
void printAll(Student s[]);
void printSt(Student s[]);
void printSb(Student s[], int id);
void addStudent(Student s[]);
void sortAverage(Student s[]);

int main() {
  std::cout << "Grading Sistem" << std::endl;
  user_menu();
  return 0;
}
// User menu that is called on the main
void user_menu()
{
  //Firing Variables
  Student *st= new Student[SIZE];
  int i=0;
  int k=0;
  string name, subject;
  float grade;
  char line[200];
  int id, sub;
  char option = 'a';
  //Reading  from file
    fstream in("student.txt");
    if (in.is_open())
    {
      while (!in.eof())
      {
        in.getline(line, sizeof(line));
        string str(line);
        istringstream iss(str);
        iss >> name;
        st[i].setStudent(name);
          while ( iss ){
        iss >> subject;
        st[i].setSubject(subject);
        iss >> grade;
        st[i].setGrade(grade);
      }

      st[i].pop(); //Earsing double read in grade
      i++;
     }
    }
    //Erasing double read in student
    i--;
    st[i].setStudent("0");
    //Closing file
    in.close();

    // Setting average for all Students
    for (int i=0; i<SIZE-1; i++) st[i].setAverage();


    while (option != 'q')
    {
        std::cout << "\nUser Menu" << std::endl;
        // Menu options
        std::cout << "  a. View grades of all the students" << std::endl;
        std::cout << "  b. View grades by Student" << std::endl;
        std::cout << "  c. View grades by Subject" << std::endl;
        std::cout << "  d. Sort by average(operator overload)" << std::endl;
        std::cout << "  e. Modify Grades" << std::endl;
        std::cout << "  f. Add new student" << std::endl;
        std::cout << "  g. Erase existing student" << std::endl;
        // Finish the program
        std::cout << "  q. Quit program" << std::endl;
        std::cout << "Choose an option: ";
        std::cin >> option;

        if (option == 'a')
        {
          printAll(st);
        }
        if (option == 'b')
        {
            printSt(st);
            std::cout << "--------------- " << std::endl;
            std::cout << "Select a student: ";
            std::cin >> id;
            st[id].setAverage();
            st[id].printStudent();
        }
        if (option == 'c')
        {
            std::cout << "--------------- " << std::endl;
            st[0].printSubject();
            std::cout << "Select a subject : ";
            std::cin >> id;
            std::cout<<endl;
            printSb(st, id);
        }
        if (option == 'd')
        {
          sortAverage(st);
          std::cout << "--------------- " << std::endl;
          std::cout << "After  sorting: ";
          printAll(st);

        }

        if (option == 'e')
        {
          std::cout << "--------------- " << std::endl;
          printSt(st);
          std::cout << "--------------- " << std::endl;
          std::cout << "Select a student to modify grade: ";
          std::cin >> id;
          std::cout << "--------------- " << std::endl;
          st[id].printSubject();
          std::cout << "Select the subject : ";
          std::cin >> sub;
          std::cout << "Current grade: "<<st[id].getGrade(sub) <<" Enter new grade: ";
          std::cin >> grade;
          st[id].setGrade(grade, sub);

        }
        if (option == 'f')
        {
          addStudent(st);

        }
        if (option == 'g')
        {
          std::cout << "--------------- " << std::endl;
          printSt(st);
          std::cout << "--------------- " << std::endl;
          std::cout << "Select a student to erase: ";
          std::cin >> id;
          st[id].erase();
        }

    }

    //Writing the data back to the file after closing program
    ofstream out("student.txt", ios::out |ios::trunc);
    if (out.is_open()) {
    for (i = 0; i < SIZE; i++) {
    if(st[i].getStudent()!="0"){
      out << st[i].getStudent() << " " <<st[0].getSubject(0) << " " << st[i].getGrade(0) << " " << st[0].getSubject(1) << " " << st[i].getGrade(1)<< " " << st[0].getSubject(2) << " " << st[i].getGrade(2)<< " " << st[0].getSubject(3) << " " << st[i].getGrade(3)<< " " << st[0].getSubject(4) << " " << st[i].getGrade(4)<< " " << st[0].getSubject(5) << " " << st[i].getGrade(5)<<endl;
      }
    }
  }
    out.close();
}

//Fuction to print all students with grades
void printAll(Student s[]){
  for(int i=0; i<SIZE-1; i++) {
    if(s[i].getStudent()!="0"){
      s[i].setAverage();
    s[i].printStudent();
  }
 }
}

//Fuction to print by student
void printSt(Student s[]){
  std::cout << "--------------- " << std::endl;
  for (int i=0; i<SIZE-1; i++){
  if(s[i].getStudent()!="0")
  std::cout <<"  "<<i<<". Student: "<<s[i].getStudent()<<  std::endl;
 }
}

//Function to print by subject
void printSb(Student s[], int id){
  for(int i=0; i<SIZE-1;i++){
    if(s[i].getStudent()!="0"){
    std::cout << "  Student: " << s[i].getStudent() << ", Grade: "<< s[i].getGrade(id) << std::endl;
   }
  }
}

//Function to add a new Student to the system
void addStudent(Student s[]){
  string name;
  float g0, g1, g2, g3, g4, g5;
  for (int i=0; i<SIZE-1; i++){
    if(s[i].getStudent()=="0"){ //Checks if student is not full
      std::cout << "Enter the new student's name: ";
      std::cin >>name;
      s[i].setStudent(name);
      std::cout << "--------------- " << std::endl;
      std::cout << "Enter the grade for "<< s[0].getSubject(0)<< " (0 if student does not take that class): ";
      std::cin >> g0;

      std::cout << "Enter the grade for "<< s[0].getSubject(1)<< " (0 if student does not take that class): ";
      std::cin >> g1;

      std::cout << "Enter the grade for "<< s[0].getSubject(2)<< " (0 if student does not take that class): ";
      std::cin >> g2;

      std::cout << "Enter the grade for "<< s[0].getSubject(3)<< " (0 if student does not take that class): ";
      std::cin >> g3;;

      std::cout << "Enter the grade for "<< s[0].getSubject(4)<< " (0 if student does not take that class): ";
      std::cin >> g4;

      std::cout << "Enter the grade for "<< s[0].getSubject(5)<< " (0 if student does not take that class): ";
      std::cin >> g5;
      s[i].newStudent(g0, g1, g2, g3, g4, g5, s[0].getSubject(0), s[0].getSubject(1), s[0].getSubject(2), s[0].getSubject(3), s[0].getSubject(4), s[0].getSubject(5) );
      break;
    }else if (i==SIZE-2)std::cout << "Can not add more students, earse one first" << std::endl;
  }
}

//fuction to sort by average using insertionSort and operator overload
void sortAverage(Student s[]) {
	for (int i = 0; i< SIZE-1; i++){
		int j=i;
		while (j > 0 && s[j] < s[j-1]){
      s[j].swap(s[j-1]);
			j--;
		}
	}
}
