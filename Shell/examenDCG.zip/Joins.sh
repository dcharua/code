#!/bin/bash
paste $1 $2 > ArchivoFinal.txt
