#!/bin/bash
history > ExamenFinal.txt
